from machine import Pin, SPI
import time
from ST7735 import TFT
from sysfont import sysfont

# --- SPI0 for TFT ---
spi = SPI(0, baudrate=20000000, polarity=0, phase=0,
          sck=Pin(18), mosi=Pin(19), miso=None)
tft = TFT(spi, 21, 20, 22)
tft.rgb(True)
tft.init_7735(tft.GREENTAB80x160)

# --- LED on GPIO27 ---
led = Pin(27, Pin.OUT)
led.value(0)

# --- Intro Screen ---
tft.fill(TFT.BLACK)
tft.text((0, 0), "RP2040", TFT.RED, sysfont, 2)
tft.text((0, 20), "USB TEST", TFT.RED, sysfont, 2)
tft.text((0, 40), "Ceyhun Pempeci", TFT.BLUE, sysfont, 2)
tft.text((0, 65), "2025", TFT.GREEN, sysfont, 2)
time.sleep(3)

# --- Main Loop ---
while True:
    try:
        # Wait for input from USB
        msg = input().strip().upper()

        # Display message
        tft.fill(TFT.BLACK)
        tft.text((0, 20), "RECEIVED:", TFT.YELLOW, sysfont, 2)
        tft.text((0, 40), msg, TFT.GREEN, sysfont, 2)

        # Handle LED commands
        if msg == "LED ON":
            led.value(1)
        elif msg == "LED OFF":
            led.value(0)

    except Exception as e:
        tft.text((0, 100), "ERROR", TFT.RED, sysfont, 1)
        print("Error:", e)

    time.sleep(0.01)